// ==UserScript==
// @name 聚焦第一个文本输入框 / 取消聚焦
// @version 0.9
// @description 按 Z 键聚焦第一个文本输入框(光标移至末尾)，按 Esc 键取消聚焦
// @author hiisme
// @match *://*/*
// @exclude *://www.notion.so/*
// @grant none
// @namespace https://greasyfork.org/users/217852
// ==/UserScript==

(function() {
    'use strict';

    // 监听键盘按下事件
    document.addEventListener('keydown', function(event) {
        // 检查是否按下了 Z 键
        if (event.key === 'z') {
            event.preventDefault(); // 阻止 Z 键的默认浏览器行为
            focusFirstTextInput();
        }
        // 检查是否按下了 Esc 键
        else if (event.key === 'Escape') {
            event.preventDefault(); // 阻止 Esc 键的默认浏览器行为
            unfocusCurrentElement();
        }
    }, false);

    // 尝试聚焦第一个文本输入框，并将光标移至末尾
    function focusFirstTextInput() {
        var inputSelector = [
            'input[type="text"]:not([disabled]):not([readonly])',
            'input[type="email"]:not([disabled]):not([readonly])',
            'input[type="password"]:not([disabled]):not([readonly])',
            'input[type="search"]:not([disabled]):not([readonly])',
            'input[type="tel"]:not([disabled]):not([readonly])',
            'input[type="url"]:not([disabled]):not([readonly])',
            'input:not([type]):not([disabled]):not([readonly])',
            'textarea:not([disabled]):not([readonly])',
            '[contenteditable="true"]:not([disabled]):not([readonly])',
            '[role="textbox"]:not([disabled]):not([readonly])'
        ].join(',');

        var allInputs = document.querySelectorAll(inputSelector);
        var firstVisibleInput = Array.from(allInputs).find(input => {
            var style = window.getComputedStyle(input);
            return style.display !== 'none' && style.visibility !== 'hidden';
        });

        if (firstVisibleInput) {
            firstVisibleInput.focus();

            // 对于普通输入框和文本区域
            if (firstVisibleInput.tagName === 'INPUT' || firstVisibleInput.tagName === 'TEXTAREA') {
                var valueLength = firstVisibleInput.value.length;
                firstVisibleInput.setSelectionRange(valueLength, valueLength);
            }
            // 对于可编辑元素(contenteditable)
            else if (firstVisibleInput.contentEditable === 'true') {
                var range = document.createRange();
                var selection = window.getSelection();
                range.selectNodeContents(firstVisibleInput);
                range.collapse(false); // false表示移动到末尾
                selection.removeAllRanges();
                selection.addRange(range);
            }
        }
    }

    // 取消当前聚焦元素的焦点
    function unfocusCurrentElement() {
        if (document.activeElement && document.activeElement !== document.body) {
            document.activeElement.blur(); // 使当前聚焦的元素失去焦点
        }
    }
})();