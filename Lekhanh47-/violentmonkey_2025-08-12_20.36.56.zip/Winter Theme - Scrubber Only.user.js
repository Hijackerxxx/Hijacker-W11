 // ==UserScript==
// @name        Winter Theme - Scrubber Only
// @namespace   Violentmonkey Scripts
// @version     1.0
// @description 仅保留视频播放器进度条的效果
// @match       *://www.youtube.com/*
// @grant       GM_addStyle
// ==/UserScript==

(function() {
    'use strict';

    // Function to add styles
    function addStyle(css) {
        var head = document.head || document.getElementsByTagName('head')[0];
        var style = document.createElement('style');
        style.type = 'text/css';
        style.appendChild(document.createTextNode(css));
        head.appendChild(style);
    }

    // CSS for the video player scrubber only
    var customCSS = `
        /* hollow knight slider */
        .ytp-scrubber-pull-indicator {
            background-color: #fff0 !important;
            height: 40px !important;
            width: 45px !important;
            background-image: url(https://media4.giphy.com/media/v1.Y2lkPTc5MGI3NjExNjExYjM5MDMxY2MwN2IwZDQ5ZjNlNjRlZDY2MGRjNjgwYzI1MGI2NSZjdD1z/Y8bAdBxtKREVcuDNyH/giphy.gif) !important;
            background-repeat: no-repeat !important;
            background-position: center !important;
            background-size: 43px, 80px !important;
            bottom: 18px !important;
            left: -10px !important;
            transform: rotate(0deg) !important;
            transform: scale(-1.5, 1.5) !important;
            border-radius: 30px !important;
        }
    `;

    addStyle(customCSS);
})();