// ==UserScript==
// @name         隐藏Bilibili热搜推荐
// @namespace    https://github.com/zhangkaixuan98/
// @version      1.0
// @description  Hide Bilibili Hot Search
// @description:zh-cn  隐藏Bilibili热搜推荐
// @author       zkx、ChatGPT
// @homepageURL  https://github.com/zhangkaixuan98/Hide_Bilibili_Hot_Search/
// @match        https://www.bilibili.com/*
// @license MIT
// @grant        none
// @connect      zhangkaixuan98.github.io
// @connect      raw.gitmirror.com
// @connect      raw.githubusercontents.com
// @connect      raw.githubusercontent.com
// @downloadURL https://update.greasyfork.org/scripts/475873/%E9%9A%90%E8%97%8FBilibili%E7%83%AD%E6%90%9C%E6%8E%A8%E8%8D%90.user.js
// @updateURL https://update.greasyfork.org/scripts/475873/%E9%9A%90%E8%97%8FBilibili%E7%83%AD%E6%90%9C%E6%8E%A8%E8%8D%90.meta.js
// ==/UserScript==
(function() {
    'use strict';
    console.log('持续检测Bilibili搜索框预填充文字更改');

    var maxAttempts = 30;
    var currentAttempt = 0;
    var newPlaceholderText = "“這不是一場叛亂嗎？”               “不，陛下，這是一場革命”";

    function checkForSearchInput() {
        var searchInput = document.querySelector('.nav-search-input');
        if (searchInput) {
            var observer = new MutationObserver(function(mutationsList, observer) {
                if (searchInput.placeholder === newPlaceholderText) {
                    console.log('输入框的值与预填充文字相同：' + newPlaceholderText);
                } else {
                    console.log('预填充文字为：' + searchInput.placeholder + '已更改为：' + newPlaceholderText);
                    searchInput.placeholder = newPlaceholderText;
                }
            });

            console.log("搜索框输入框已出现" + searchInput.placeholder);
            searchInput.placeholder = newPlaceholderText;
            observer.observe(searchInput, { attributes: true, attributeFilter: ['placeholder'] });
            return;
        } else {
            currentAttempt++;
            if (currentAttempt < maxAttempts) {
                setTimeout(checkForSearchInput, 100);
            } else {
                console.log("已达到最大尝试次数，搜索框输入框未出现");
            }
        }
    }

    checkForSearchInput();
})();
